class Bingo {
    #listadoCartones
    #bolasPorSalir
    #timer
    #hayLinea

    constructor() {
        this.#listadoCartones=[];
        this.showBolas();
    }

    /**
     * Funcion que devuelve la siguiente bola
     * 
     * @return {int}
     */
    obtenerSiguienteBola() {
        return this.#bolasPorSalir.splice(Math.floor(Math.random()*this.#bolasPorSalir.length), 1)[0];
    }

    /**
     * Funcion que muestra las bolas en el tablero
     */
    showBolas() {
        document.getElementById("tablero").innerHTML=Array.from(Array(90)).map((el, index) => "<div id='b"+(index+1)+"'>"+(index+1)+"</div>").join("");
    }

    /**
     * Funcion para almacenar un nuevo carton
     * 
     * @param {carton} carton
     */
    addCarton(carton) {
        this.#listadoCartones.push(carton);
    }

    /**
     * Función para mostrar los cartones en la web
     */
    showCartones() {
        const cartones=document.getElementById("cartones");
        this.#listadoCartones.forEach((el, index) => cartones.insertAdjacentHTML("beforeend", el.dibujarCarton(index)));
    }

    /**
     * Metodo para eliminar los cartones
     */
    clearCartones() {
        document.getElementById("cartones").innerHTML="";
        document.getElementById("historial").innerHTML="";
        this.#listadoCartones=[];
    }

    /**
     * Funcion que se ejecuta al empezar el bingo
     */
    start(velocidad) {
        this.#bolasPorSalir=Array.from(Array(90), (v, i) => i+1);
        this.#hayLinea=false;
        this.iniciar(velocidad);
    }

    /**
     * Funcion para pausar el bingo
     */
    pause(velocidad) {
        if (this.#timer) {
            Bingo.historial("Pausado!!!");
            clearInterval(this.#timer);
            this.#timer=false;
        } else {
            Bingo.historial("Reanudado!!!");
            this.iniciar(velocidad);
        }
        return this.#timer;
    }

    /**
     * Funcion para iniciar el bingo o reiniciar despues de una pausa
     */
    iniciar(velocidad) {
        this.#timer=setInterval(() => {
            // buscamos la siguiente bola
            const siguienteBola=this.obtenerSiguienteBola();
            // marcamos la bola en el tablero
            document.getElementById("b"+siguienteBola).classList.add("check");
            // mostramos el texto
            Bingo.historial("Bola: "+(90-this.#bolasPorSalir.length)+" - Ha salido el numero "+siguienteBola);

            // revisamos el numero en cada uno de los cartones
            this.#listadoCartones.map((el, index) => el.marcarNumero(siguienteBola, index));
            // revisamos si algun carton tiene linea
            if (!this.#hayLinea) {
                this.#hayLinea=this.checkLineas();
            } else {
                if (this.checkBingo()) {
                    this.end();
                }
            }
        }, velocidad);
    }

    end() {
        Bingo.historial("Parado!!!");
        clearInterval(this.#timer);
    }

    checkLineas() {
        return this.#listadoCartones.filter((el, index) => {
            const linea=el.tieneLinia();
            if (linea) {
                Bingo.historial("LINEA en el carton "+(index)+" con "+(90-this.#bolasPorSalir.length)+" bolas - linea "+linea, "linea");
                return true;
            }
        }).length>0;
    }

    checkBingo() {
        return this.#listadoCartones.filter((el, index) => {
            const bingo=el.tieneBingo();
            if (bingo) {
                Bingo.historial("BINGO en el carton "+index+" con "+(90-this.#bolasPorSalir.length)+" bolas", "bingo");
                document.dispatchEvent(new CustomEvent('finalBingo'));
                return true;
            }
        }).length>0;
    }

    static historial(text, className="") {
        const zero = (n) => n.toString().length==1 ? "0"+n : n.toString();
        const x=new Date();
        text=zero(x.getHours())+":"+zero(x.getMinutes())+":"+zero(x.getSeconds())+" - "+text;
        const hist=document.getElementById("historial");
        historial.insertAdjacentHTML("beforeend","<div class='"+className+"'>"+text+"</div>");
        historial.scrollTop = historial.scrollHeight;
    }
}
