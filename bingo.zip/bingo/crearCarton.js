class CrearCarton {
    /**
     * Funcion que genera los numeros
     */
    generarNumeros() {
        // obtenemos las 3 columnas que solo tendran un numero y dos posiciones sin numeros
        const posicionesConUnNumero=this.obtenerNumerosAleatoriosSinRepetirse(0, 8, 3);
        // obtenemos los 15 valores del carton
        let numeros=Array.from(Array(9)).reduce((acum, el, i) => [...acum, ...this.agregarValoresNegros(
                this.obtenerNumerosAleatoriosSinRepetirse(
                    (i*10)+1, (i==8) ? 90 : (i*10)+9, posicionesConUnNumero.indexOf(i)==-1 ? 2 : 1
                )
            )], []
        );
        // convertimos cada valor en un array de arrays, que contendra
        // los numeros y un valor para determinar si ha salido [[3, 0], [14, 0], ...]
        return this.posicionarCincoPorLinea(numeros, 0, 1).map(el => [el, 0]);
    }

    /**
     * Funcion que añade los puntos negros (posiciones sin numeros) a cada columna
     * 
     * @param {array} array 
     * @return {array} devuelve el array inicial con las posiciones sin numeros
     */
    agregarValoresNegros(array) {
        const num=Math.floor(Math.random()*3);
        // agregamos un cuadro negro o dos segun la longitud del array
        return (array.length==2) ? [...array.slice(0, num), 0, ...array.slice(num)] : [...[0, 0, 0].slice(0,num), array[0], ...[0, 0, 0].slice(num+1)];
    }

    /**
     * Funcion recursiva que comprueba y corrige que haya cinco numeros por linea
     * 
     * @param {array} array - array de los numeros
     * @param {int} fila1 - fila a añadir o eliminar elementos
     * @param {int} fila2 - fila con la que intercambiara los valores la fila1
     * @return {array} array modificado con los numeros bien puestos
     */
    posicionarCincoPorLinea(array, fila1, fila2) {
        if (fila1==2) {
            return array;
        }
        let numeros1Fila=array.slice(fila1).filter((el, index) => index%3==0);
        let numeros2Fila=array.slice(fila2).filter((el, index) => index%3==0);

        let cantidad1Fila=numeros1Fila.reduce((acum, el) => el!=0 ? ++acum : acum, 0);
        if (cantidad1Fila==5) {
            return this.posicionarCincoPorLinea(array, fila1+1, fila2+1);
        } else if (cantidad1Fila<5) {
            // obtenemos los posibles valor de la segunda fila que pueden subir a la fila superior
            const posiblesValoresASubir=numeros2Fila.filter((el, index) => (el!=0 && numeros1Fila[index]==0));
            if (posiblesValoresASubir.length==0) {
                return this.posicionarCincoPorLinea(array, fila1, fila2+1);
            }
            // obtenemos aleatoriamente el valor a subir
            const posicionASubir=Math.floor(Math.random()*posiblesValoresASubir.length);
            // obtenemos la posicion del elemento dentro del array de la segunda fila
            const pos=numeros2Fila.indexOf(posiblesValoresASubir[posicionASubir]);
            // reemplazamos los valores
            [array[fila1+(pos*3)], array[fila2+(pos*3)]] = [array[fila2+(pos*3)], 0];
        } else if (cantidad1Fila>5) {
            // obtenemos los posibles valor de la primera fila que pueden bajar a la fila inferior
            const posiblesValoresABajar=numeros1Fila.filter((el, index) => (el!=0 && numeros2Fila[index]==0));
            if (posiblesValoresABajar.length==0) {
                return this.posicionarCincoPorLinea(array, fila1, fila2+1);
            }
            // obtenemos aleatoriamente el valor a bajar
            const posicionABajar=Math.floor(Math.random()*posiblesValoresABajar.length);
            // obtenemos la posicion del elemento dentro del array de la primera fila
            const pos=numeros1Fila.indexOf(posiblesValoresABajar[posicionABajar]);
            // reemplazamos los valores
            [array[fila2+(pos*3)], array[fila1+(pos*3)]] = [array[fila1+(pos*3)], 0];
        }
        return this.posicionarCincoPorLinea(array, fila1, fila1+1);
    }

    /**
     * Funcion para devolver un array de n numeros aleatorios entre un rango de valores
     * 
     * Ejemplo:
     *  (1, 10, 2) Devuelve dos numeros entre el 1 y el 10 inclusivos
     *  (10, 21, 5) Devuelve cinco numeros entre el 10 y el 21 inclusivos
     * 
     * @param {int} desde valor inicial incluido
     * @param {int} hasta valor final incluido
     * @param {int} cantidad cantidad de numeros a devolver
     * @return {array}
     */
    obtenerNumerosAleatoriosSinRepetirse(desde, hasta, cantidad) {
        const miArray=Array.from(Array(hasta+1-desde), (el,i) => i+desde);
        return Array.from({length: cantidad}).map(() => miArray.splice(Math.floor(Math.random()*miArray.length), 1)[0]).sort((a, b) => a - b);
    }
}