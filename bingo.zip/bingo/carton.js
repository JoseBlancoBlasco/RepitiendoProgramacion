class Carton {
    /** 
     * Contiene un array con los valores del carton
     * 
     * Si el carton es (los 0 son los espacios negros):
     *  1  0 24 35 44  0  0 72  0
     *  0 14 27 37  0 52 61  0  0
     *  8 46  0  0  0  0 65 78 82
     * El array sera:
     *  1  0 24 35 44  0  0 72  0  0 14 27 37  0 52 61  0  0  8 46  0  0  0  0 65 78 82
     */
    #numeros

    constructor() {
        const cc=new CrearCarton();
        this.#numeros=cc.generarNumeros()
    }

    /**
     * Funcion que devuelve el código html del carton
     * 
     * @param {int} id - identificador que hace referencia al numero de carton
     * @return {string} - codigo html que muestra el carton
     */
    dibujarCarton(id) {
        const numeros=this.#numeros.concat(this.#numeros.slice(1, this.#numeros.length)).concat(this.#numeros.slice(1, this.#numeros.length));
        const result=numeros.filter((el, index) => index%3==0).map((el, index) => el[0]==0 ? "<div class='cartonBlack'>&nbsp;</div>" : "<div data-n='"+(el[0])+"'>"+(el[0])+"</div>");
        return "<div id='carton"+id+"' class='carton'><h4>Carton: "+id+"</h4>"+result.join("")+"</div>";
    }

    /**
     * Funcion que marca el numero salido en el array de numeros y en el carton
     * 
     * @param {int} num numero a marcar
     * @param {int} id identificador del carton
     */
    marcarNumero(num, id) {
        this.#numeros.some((el, index) => {
            if (num==el[0]) {
                // marcamos el array
                this.#numeros[index][1]=1;
                // marcamos el numero en el carton
                document.getElementById("carton"+id).querySelector("[data-n='"+num+"'").classList.add("check");
                Bingo.historial("Numero encontrado en carton "+id);
                return true;
            }
        });
    }
    
    /**
     * Funcion que revisa si alguna linea esta completa
     * 
     * @return {integer|false} - Devuelve el numero de la linea o false
     */
    tieneLinia() {
        if (this.#numeros.filter((el, index) => index%3==0).every(el => el[0]==0 || el[1]==true)) {
            return 1;
        }
        if (this.#numeros.slice(1).filter((el, index) => index%3==0).every(el => el[0]==0 || el[1]==true)) {
            return 2;
        }
        if (this.#numeros.slice(2).filter((el, index) => index%3==0).every(el => el[0]==0 || el[1]==true)) {
            return 3;
        }
        return false;
    }

    /**
     * Funcion que revisa si estan todas las casillas marcadas
     * 
     * @return {boolean}
     */
    tieneBingo() {
        return this.#numeros.every(el => el[0]==0 || el[1]==true);
    }
}