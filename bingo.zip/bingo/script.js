(function(){
    const bingo=new Bingo();
    const buttonStart=document.getElementById("start");
    const buttonPause=document.getElementById("pause");
    const buttonEnd=document.getElementById("finalizar");
    const velocidad=document.getElementById("velocidad");
    const ncartones=document.getElementById("ncartones");

    buttonStart.addEventListener("click", ()=>{
        bingo.clearCartones();
        bingo.showBolas();

        for (let i=0, cartones=parseInt(ncartones.value); i<cartones; i++) {
            bingo.addCarton(new Carton());
        }

        bingo.showCartones();
        bingo.start(velocidad.value*100);
        botonesjugando();
    });

    buttonPause.addEventListener("click", ()=>{
        if (bingo.pause(velocidad.value*100)) {
            botonesjugando();
        } else {
            botonesPause();
        }
    });

    buttonEnd.addEventListener("click", ()=>{
        bingo.end();
        botonesNoJugando();
    });

    document.addEventListener("finalBingo", ()=>{
        botonesNoJugando();
    });

    velocidad.addEventListener("input", function(){
        this.nextElementSibling.innerText=this.value;
    });

    const botonesNoJugando = () => {
        buttonStart.disabled=false;
        velocidad.disabled=false;
        ncartones.disabled=false;
        buttonPause.disabled=true;
        buttonEnd.disabled=true;
    }
    const botonesjugando = () => {
        buttonStart.disabled=true;
        velocidad.disabled=true;
        ncartones.disabled=true;
        buttonPause.disabled=false;
        buttonEnd.disabled=false;
    }
    const botonesPause = () => {
        velocidad.disabled=false;
    }

})();

