/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author j.blanco
 */
public class Borrame {
    //    @Override
//    public void cobrar(Recurso recurso, int cantidad) {
//        String tipo = recurso.getTipo();
//        if (tipo.equals("fruta") && this.getFrutaTotal() >= cantidad) {
//            this.monedas += 5 * cantidad;
//            this.frutaTotal -= cantidad;
//        } else if (tipo.equals("verdura") && this.getVerduraTotal() >= cantidad) {
//            this.monedas += 3 * cantidad;
//            this.verduraTotal -= cantidad;
//        } else {
//            System.out.println("No trabajo ese recurso, no puedo cobrarte.");
//        }
//    }
//    @Override
//    public void pagar(Sujeto sujeto, int cantidad) {
//        if (this.monedas >= cantidad) {
//            this.monedas -= cantidad;
//            sujeto.setCantidadMonedas(+cantidad);
//        } else {
//            System.out.println("No tengo ese dinero.");
//        }
//    }
//    @Override
//    public int getMonedas() {
//        return this.monedas;
//    }
//    public boolean recolectarFruta(int cantidad) {
//        if (cantidad > 0) {
//            int frutaObtenida = cantidad * 5;
//            this.frutaTotal += frutaObtenida;
//            return true;
//        } else {
//            return false;
//        }
//    }
//
//    public boolean recolectarVerdura(int cantidad) {
//        if (cantidad > 0) {
//            int verduraObtenida = cantidad * 2;
//            this.verduraTotal += verduraObtenida;
//            return true;
//        } else {
//            return false;
//        }
//    }
    
    //    @Override
//    public void setMonedas(int monedas) {
//        this.monedas = monedas;
//    }
}
