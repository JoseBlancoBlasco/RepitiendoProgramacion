
public interface Dinero {

    void transaccion(Sujeto sujeto, Recurso recurso, int cantidad);
}
