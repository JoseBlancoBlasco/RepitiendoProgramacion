
public enum TipoRecurso {
    HARINA,
    PEZ,
    ORO,
    BOSQUE,
    GANADO,
    FRUTA,
    VERDURA,
    PAN,
    MADERA,
    COMBUSTIBLE,
    MUEBLES,
    CARNE,
    TRUCHAS,
    CANGREJOS,
    MONEDAS
}
