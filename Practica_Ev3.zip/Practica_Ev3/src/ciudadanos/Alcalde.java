package ciudadanos;

import core.Recurso;
import core.Dinero;
import core.Movimiento;
import core.Sujeto;
import java.util.List;

public class Alcalde extends Sujeto implements Movimiento, Dinero {

    private double recaudacion;

    public Alcalde() {
        super();
        this.recaudacion = 0;
    }

    public Alcalde(int id, int cantidadVida, int posX, int posY, int velocidadMovimiento,
            double[] cantidadRecursos, double tasaImpuestos, double recaudacion) {
        super();
        this.recaudacion = recaudacion;
    }

    public void redistribuirImpuestos(List<Alguacil> alguaciles, List<Sujeto> sujetos) {
        if (alguaciles.isEmpty()) {
            System.out.println("No hay alguaciles para recaudar impuestos.");
            return;
        }

        if (sujetos.isEmpty()) {
            System.out.println("No hay sujetos para redistribuir impuestos.");
            return;
        }

        double impuestosTotales = 0;
        for (Alguacil alguacil : alguaciles) {
            impuestosTotales += alguacil.getRecaudacion();
            alguacil.setRecaudacion(0);
        }

        if (impuestosTotales == 0) {
            System.out.println("No hay impuestos recaudados para redistribuir.");
            return;
        }

        int totalSujetos = sujetos.size();
        double impuestosPorSujeto = impuestosTotales / totalSujetos;

        for (Sujeto sujeto : sujetos) {
            sujeto.getCantidadRecursos()[14] += impuestosPorSujeto;
        }

        this.recaudacion += impuestosTotales;
    }

    public double getRecaudacion() {
        return recaudacion;
    }

    public void setRecaudacion(double recaudacion) {
        this.recaudacion = recaudacion;
    }

    @Override
    public boolean subir() {
        if (getPosY() > 0) {
            setPosY(getPosY() - 1);
            return true;
        }
        return false;
    }

    @Override
    public boolean bajar() {
        if (getPosY() < 49) {
            setPosY(getPosY() + 1);
            return true;
        }
        return false;
    }

    @Override
    public boolean derecha() {
        if (getPosX() < 49) {
            setPosX(getPosX() + 1);
            return true;
        }
        return false;
    }

    @Override
    public boolean izquierda() {
        if (getPosX() > 0) {
            setPosX(getPosX() - 1);
            return true;
        }
        return false;
    }

    @Override
    public boolean irA(int posX, int posY) {
        if (posX < 0 || posX > 49 || posY < 0 || posY > 49) {
            return false;
        }
        setPosX(posX);
        setPosY(posY);
        return true;
    }
    
    public void recolectarRecurso(Recurso recurso) {
        switch (recurso.getTipo()) {
            case HARINA:
                agregarCantidadRecurso(1, 0);
                recurso.extraerRecurso(1);
                break;
            case PEZ:
                agregarCantidadRecurso(1, 1);
                recurso.extraerRecurso(1);
                break;
            case ORO:
                agregarCantidadRecurso(1, 2);
                recurso.extraerRecurso(1);
                break;
            case BOSQUE:
                agregarCantidadRecurso(1, 3);
                recurso.extraerRecurso(1);
                break;
            case GANADO:
                agregarCantidadRecurso(1, 4);
                recurso.extraerRecurso(1);
                break;
            case FRUTA:
                agregarCantidadRecurso(1, 5);
                recurso.extraerRecurso(1);
                break;
            case VERDURA:
                agregarCantidadRecurso(1, 6);
                recurso.extraerRecurso(1);
                break;
            default:
                break;
        }
    }

    @Override
    public void transaccion(Sujeto sujeto, Recurso recurso, int cantidad, double precio) {
        System.out.println("Como buen Alcalde que soy, no produzco nada solo hago gasto público.");
    }

    public void repartirRecaudacion(List<Sujeto> sujetos, List<Alguacil> alguaciles, List<Alcalde> alcaldes, double recaudacion) {
        if (sujetos.isEmpty() && alguaciles.isEmpty() && alcaldes.isEmpty()) {
            System.out.println("No hay ciudadanos para repartir la recaudación.");
            return;
        }

        double recaudacionPorSujeto = recaudacion / (sujetos.size() + alguaciles.size() + alcaldes.size());

        for (Sujeto sujeto : sujetos) {
            sujeto.agregarCantidadRecurso(recaudacionPorSujeto, 14);
        }

        for (Alguacil alguacil : alguaciles) {
            alguacil.agregarCantidadRecurso(recaudacionPorSujeto, 14);
        }
        
        for (Alcalde alcalde : alcaldes) {
            alcalde.agregarCantidadRecurso(recaudacionPorSujeto, 14);
        }

        System.out.println("Recaudación repartida entre los ciudadanos exitosamente.");
    }

}
