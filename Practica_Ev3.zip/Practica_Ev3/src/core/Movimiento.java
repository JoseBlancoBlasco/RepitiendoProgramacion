package core;

public interface Movimiento {
    boolean subir();
    boolean bajar();
    boolean derecha();
    boolean izquierda();
    boolean irA(int posX, int posY);
}
